#Create a bar chart to represent monthly expenses in different spending categories and give your conclusion. 
#Input: categories = ['Rent', 'Groceries', 'Utilities', 'Entertainment', 'Transportation'] 
#Monthly expenses in dollars (replace with your own data) 
#expenses = [1200, 400, 200, 150, 250]




import matplotlib.pyplot as plt

# Data for the chart
categories = ['Rent', 'Groceries', 'Utilities', 'Entertainment', 'Transportation']
expenses = [1200, 400, 200, 150, 250]

# Creating the bar chart
plt.bar(categories, expenses, color='cornflowerblue')
plt.xlabel('Categories')
plt.ylabel('Expenses')
plt.title('Monthly Expenses by Category')


# Displaying the bar chart
plt.show()
